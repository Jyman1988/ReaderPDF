"use client";

import { useEffect, useState } from "react";
import { Trash2 } from "lucide-react";
import { pi } from "@/lib/pi";
import { LIBRARY_KEY, PREFS_KEY } from "@/lib/reader/data";
import { useReader } from "@/contexts/reader-context";
import { Button, Sheet } from "./ui";

export function StorageFullSheet() {
  const { storageFull, dismissFull, library, removeDoc } = useReader();
  const [keys, setKeys] = useState<string[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (!storageFull) return;
    setKeys(null);
    pi.userState
      .keys()
      .then((k) => setKeys(Array.isArray(k) ? k.filter((x) => typeof x === "string") : []))
      .catch(() => setKeys([]));
  }, [storageFull]);

  const labelFor = (key: string) => {
    if (key === PREFS_KEY) return { label: "Preferencias de voz", protected: true };
    if (key === LIBRARY_KEY) return { label: "Biblioteca", protected: true };
    const m = /^readerpdf\.n\.(.+)$/.exec(key);
    if (m) {
      const doc = library.find((d) => d.id === m[1]);
      return { label: doc ? `Notas de «${doc.title}»` : "Notas de un documento eliminado", protected: false, docId: doc?.id };
    }
    return { label: "Datos antiguos", protected: false };
  };

  const remove = async (key: string, docId?: string) => {
    setBusy(key);
    try {
      if (docId) removeDoc(docId);
      else await pi.userState.delete(key);
      setKeys((k) => (k ? k.filter((x) => x !== key) : k));
    } catch {
      /* keep list */
    } finally {
      setBusy(null);
    }
  };

  return (
    <Sheet
      open={storageFull}
      onClose={dismissFull}
      title="Tu espacio está lleno"
      footer={
        <Button block variant="outline" onClick={dismissFull}>
          Seguir sin liberar espacio
        </Button>
      }
    >
      <p className="text-sm leading-relaxed text-muted-foreground">
        No podemos guardar más datos en tu cuenta Pi. Tus cambios siguen en pantalla; libera espacio eliminando
        elementos que ya no necesites.
      </p>
      <ul className="mt-4 flex flex-col gap-2">
        {keys === null ? (
          <li className="text-sm text-muted-foreground">Cargando…</li>
        ) : keys.length === 0 ? (
          <li className="text-sm text-muted-foreground">No hay elementos que puedas eliminar.</li>
        ) : (
          keys.map((k) => {
            const info = labelFor(k);
            return (
              <li key={k} className="flex items-center justify-between gap-3 rounded-xl border border-border px-3 py-2.5">
                <span className="min-w-0 truncate text-sm">
                  {info.label}
                  {"docId" in info && info.docId ? (
                    <span className="block text-xs text-muted-foreground">Elimina el documento y sus notas</span>
                  ) : null}
                </span>
                {info.protected ? (
                  <span className="text-xs text-muted-foreground">Necesario</span>
                ) : (
                  <Button variant="ghost" className="px-3 py-2 text-destructive" disabled={busy === k} onClick={() => remove(k, "docId" in info ? info.docId : undefined)}>
                    <Trash2 className="h-4 w-4" />
                    Eliminar
                  </Button>
                )}
              </li>
            );
          })
        )}
      </ul>
    </Sheet>
  );
}
