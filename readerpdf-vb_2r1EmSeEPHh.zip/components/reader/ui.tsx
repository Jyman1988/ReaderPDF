"use client";

import { useEffect } from "react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { X } from "lucide-react";
import { useReader } from "@/contexts/reader-context";

export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

type Variant = "primary" | "outline" | "ghost" | "danger" | "soft";

const VARIANTS: Record<Variant, string> = {
  primary: "bg-primary text-primary-foreground hover:opacity-95 shadow-sm",
  outline: "border border-border bg-card text-foreground hover:bg-muted",
  ghost: "text-foreground hover:bg-muted",
  danger: "bg-destructive text-primary-foreground hover:opacity-95",
  soft: "bg-secondary text-secondary-foreground hover:opacity-90",
};

export function Button({
  variant = "primary",
  block,
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; block?: boolean }) {
  return (
    <button
      type="button"
      {...rest}
      className={cx(
        "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50",
        VARIANTS[variant],
        block && "w-full",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function IconButton({
  label,
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      {...rest}
      className={cx(
        "inline-flex h-10 w-10 items-center justify-center rounded-full text-foreground transition hover:bg-muted active:scale-95 disabled:opacity-40",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" aria-label="Cerrar" className="rp-fade absolute inset-0 bg-foreground/35" onClick={onClose} />
      <div className="rp-sheet relative flex max-h-[88dvh] w-full max-w-lg flex-col rounded-t-3xl bg-card shadow-2xl sm:rounded-3xl">
        <div className="flex items-center justify-between gap-2 px-5 pb-2 pt-4">
          <h2 className="text-lg font-semibold">{title}</h2>
          <IconButton label="Cerrar" onClick={onClose}>
            <X className="h-5 w-5" />
          </IconButton>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-5">{children}</div>
        {footer ? <div className="border-t border-border px-5 py-3 rp-safe-bottom">{footer}</div> : null}
      </div>
    </div>
  );
}

export function ToastHost() {
  const { toasts } = useReader();
  if (!toasts.length) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-[70] flex flex-col items-center gap-2 px-4" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="rp-toast rounded-full bg-foreground px-4 py-2 text-sm font-medium text-background shadow-lg">
          {t.text}
        </div>
      ))}
    </div>
  );
}

export function StorageNotice() {
  const { storageTrouble } = useReader();
  if (!storageTrouble) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 top-14 z-[60] flex justify-center px-4" role="status">
      <div className="rounded-full border border-border bg-card px-4 py-1.5 text-xs text-muted-foreground shadow">
        Guardando en tu cuenta Pi… lo reintentamos en unos segundos
      </div>
    </div>
  );
}
