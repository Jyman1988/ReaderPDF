"use client";

import { useState } from "react";
import type { KeyboardEvent } from "react";
import { Pencil, StickyNote, Trash2 } from "lucide-react";
import { NOTE_MAX, relativeTime } from "@/lib/reader/data";
import { useReader } from "@/contexts/reader-context";
import { Button, Sheet, cx } from "./ui";

export function NotesSheet({
  docId,
  open,
  onClose,
  currentPage,
}: {
  docId: string;
  open: boolean;
  onClose: () => void;
  currentPage: number;
}) {
  const { notesFor, addNote, updateNote, deleteNote } = useReader();
  const notes = notesFor(docId);
  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  const submit = () => {
    if (!draft.trim()) return;
    addNote(docId, draft, currentPage);
    setDraft("");
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      if (e.nativeEvent.isComposing || e.keyCode === 229) return;
      e.preventDefault();
      submit();
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Mis notas">
      <div className="rounded-2xl border border-border bg-muted/50 p-3">
        <label htmlFor="new-note" className="sr-only">
          Nueva nota
        </label>
        <textarea
          id="new-note"
          value={draft}
          onChange={(e) => setDraft(e.target.value.slice(0, NOTE_MAX))}
          onKeyDown={onKey}
          rows={3}
          placeholder="Escribe una nota sobre lo que estás estudiando…"
          className="w-full resize-none bg-transparent text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground"
        />
        <div className="mt-2 flex items-center justify-between gap-2">
          <span className="text-xs text-muted-foreground">{currentPage > 0 ? `Se vinculará a la página ${currentPage}` : ""}</span>
          <Button className="px-4 py-2" onClick={submit} disabled={!draft.trim()}>
            Guardar nota
          </Button>
        </div>
      </div>

      <div className="mt-5 flex flex-col gap-3">
        {notes === null ? (
          <p className="text-sm text-muted-foreground">Cargando notas…</p>
        ) : notes.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <StickyNote className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">Aún no tienes notas en este documento.</p>
          </div>
        ) : (
          notes.map((n) => (
            <article key={n.id} className="rounded-2xl border border-border bg-card p-3">
              <div className="mb-1.5 flex items-center justify-between gap-2 text-xs text-muted-foreground">
                <span>
                  {n.page > 0 ? `Página ${n.page} · ` : ""}
                  {relativeTime(n.updatedAt)}
                </span>
                {editing !== n.id ? (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      className="inline-flex items-center gap-1 rounded-lg px-2 py-1 font-medium hover:bg-muted"
                      onClick={() => {
                        setEditing(n.id);
                        setEditText(n.text);
                        setConfirmDel(null);
                      }}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      Editar
                    </button>
                    <button
                      type="button"
                      className={cx(
                        "inline-flex items-center gap-1 rounded-lg px-2 py-1 font-medium",
                        confirmDel === n.id ? "bg-destructive text-primary-foreground" : "text-destructive hover:bg-muted",
                      )}
                      onClick={() => {
                        if (confirmDel === n.id) {
                          deleteNote(docId, n.id);
                          setConfirmDel(null);
                        } else setConfirmDel(n.id);
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      {confirmDel === n.id ? "¿Eliminar?" : "Eliminar"}
                    </button>
                  </div>
                ) : null}
              </div>
              {editing === n.id ? (
                <div>
                  <label htmlFor={`edit-${n.id}`} className="sr-only">
                    Editar nota
                  </label>
                  <textarea
                    id={`edit-${n.id}`}
                    value={editText}
                    onChange={(e) => setEditText(e.target.value.slice(0, NOTE_MAX))}
                    rows={4}
                    autoFocus
                    className="w-full resize-none rounded-xl border border-border bg-background p-2 text-[15px] leading-relaxed outline-none focus:border-primary"
                  />
                  <div className="mt-2 flex justify-end gap-2">
                    <Button variant="ghost" className="px-3 py-2" onClick={() => setEditing(null)}>
                      Cancelar
                    </Button>
                    <Button
                      className="px-3 py-2"
                      disabled={!editText.trim()}
                      onClick={() => {
                        updateNote(docId, n.id, editText);
                        setEditing(null);
                      }}
                    >
                      Guardar
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">{n.text}</p>
              )}
            </article>
          ))
        )}
      </div>
    </Sheet>
  );
}
