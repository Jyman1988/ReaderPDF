"use client";

import { ReaderApp } from "@/components/reader-app";

export default function HomePage() {
  return <ReaderApp />;
}
