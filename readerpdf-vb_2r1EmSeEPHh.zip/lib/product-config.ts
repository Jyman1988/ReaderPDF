export const PRODUCT_CONFIG = {
  PRODUCT_6ab7ccccdf9008f0e172a470: "6ab7ccccdf9008f0e172a470",
} as const;
