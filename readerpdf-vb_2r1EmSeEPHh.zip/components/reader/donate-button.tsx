"use client";

import { useState } from "react";
import { Heart, Loader2 } from "lucide-react";
import { usePiAuth } from "@/contexts/pi-auth-context";
import { useReader } from "@/contexts/reader-context";
import { PRODUCT_CONFIG } from "@/lib/product-config";
import { Button, cx } from "./ui";

export function DonateButton({ className }: { className?: string }) {
  const { products, sdk } = usePiAuth();
  const { toast } = useReader();
  const [busy, setBusy] = useState(false);

  const product = products?.find((p) => p.id === PRODUCT_CONFIG.PRODUCT_6ab7ccccdf9008f0e172a470) ?? null;
  const amount = product?.price_in_pi;

  const onClick = async () => {
    if (!product || !sdk || busy) return;
    setBusy(true);
    try {
      const result = await sdk.makePurchase(product.slug);
      if (result.ok) {
        toast(`¡Gracias por tu aporte de ${amount} Pi!`);
      }
    } catch (err: any) {
      if (err?.code === "purchase_cancelled") {
        // user cancelled, no message needed
      } else if (err?.code === "product_not_found") {
        toast("No se encontró el producto de contribución.");
      } else {
        toast("No se pudo completar la contribución. Intenta de nuevo.");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <Button
      variant="outline"
      className={cx("shrink-0 whitespace-nowrap py-4 text-base", className)}
      disabled={!product || !sdk || busy}
      onClick={onClick}
      aria-label={product ? `Contribuir al desarrollo por ${amount} Pi` : "Contribuir al desarrollo no disponible"}
    >
      {busy ? (
        <Loader2 className="h-5 w-5 animate-spin" />
      ) : (
        <Heart className="h-5 w-5" aria-hidden="true" />
      )}
      {product ? `Contribuir · ${amount} Pi` : "Contribuir"}
    </Button>
  );
}
