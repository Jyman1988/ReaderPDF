"use client";

import { ShieldCheck } from "lucide-react";
import { Sheet } from "./ui";

export function LegalSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Sheet open={open} onClose={onClose} title="Privacidad y condiciones">
      <div className="flex flex-col gap-6 pb-2 text-sm leading-relaxed text-foreground">
        <div className="flex items-center gap-2 rounded-2xl bg-secondary px-4 py-3 text-secondary-foreground">
          <ShieldCheck className="h-5 w-5 shrink-0" aria-hidden="true" />
          <p className="text-xs">
            Este resumen explica, en lenguaje sencillo, cómo funciona ReaderPDF respecto a tus datos y al uso de la app.
          </p>
        </div>

        <section aria-labelledby="privacidad-title" className="flex flex-col gap-2">
          <h3 id="privacidad-title" className="text-base font-semibold">
            Política de privacidad
          </h3>
          <p className="text-muted-foreground">
            ReaderPDF está pensada para ayudarte a escuchar tus documentos PDF (libros, temarios, apuntes) sin
            comprometer tu privacidad.
          </p>
          <ul className="ml-4 flex flex-col gap-2 [&>li]:list-disc">
            <li>
              <span className="font-medium text-foreground">Documentos y notas:</span> los PDF que agregas, tu
              progreso de lectura y tus notas se guardan de forma asociada a tu cuenta de Pi Network, para que estén
              disponibles la próxima vez que abras la app.
            </li>
            <li>
              <span className="font-medium text-foreground">Sin publicidad ni venta de datos:</span> no compartimos,
              vendemos ni cedemos tus documentos o datos a terceros con fines comerciales o publicitarios.
            </li>
            <li>
              <span className="font-medium text-foreground">Lectura en voz alta:</span> la conversión de texto a voz
              se realiza mediante las funciones de tu propio navegador o dispositivo; el contenido de tus documentos
              no se envía a servidores externos para ser leído en voz alta.
            </li>
            <li>
              <span className="font-medium text-foreground">Autenticación con Pi:</span> usamos el inicio de sesión
              de Pi Network únicamente para identificarte y guardar tu información de forma privada bajo tu cuenta.
            </li>
            <li>
              <span className="font-medium text-foreground">Control de tus datos:</span> puedes eliminar en
              cualquier momento los documentos y notas guardados desde tu biblioteca.
            </li>
          </ul>
        </section>

        <section aria-labelledby="condiciones-title" className="flex flex-col gap-2">
          <h3 id="condiciones-title" className="text-base font-semibold">
            Condiciones de uso
          </h3>
          <ul className="ml-4 flex flex-col gap-2 [&>li]:list-disc">
            <li>
              <span className="font-medium text-foreground">Uso personal:</span> ReaderPDF es una herramienta de
              apoyo a la lectura y el estudio. Eres responsable del contenido de los documentos que subes y de
              contar con los derechos necesarios para usarlos.
            </li>
            <li>
              <span className="font-medium text-foreground">Contenido permitido:</span> no debes subir documentos
              con contenido ilegal, difamatorio, o que infrinja derechos de propiedad intelectual de terceros.
            </li>
            <li>
              <span className="font-medium text-foreground">Disponibilidad del servicio:</span> hacemos lo posible
              por mantener la app disponible y tus datos guardados, pero no podemos garantizar un funcionamiento
              ininterrumpido ni la ausencia total de errores técnicos.
            </li>
            <li>
              <span className="font-medium text-foreground">Aportaciones voluntarias:</span> cualquier pago o
              contribución realizada dentro de la app mediante Pi Network es voluntaria y se procesa a través de los
              sistemas oficiales de Pi Network.
            </li>
            <li>
              <span className="font-medium text-foreground">Cambios:</span> estas condiciones y esta política pueden
              actualizarse para reflejar mejoras o cambios en la app; seguir usando ReaderPDF implica aceptar la
              versión vigente.
            </li>
          </ul>
        </section>

        <p className="text-xs text-muted-foreground">
          Si tienes dudas sobre cómo se tratan tus datos o sobre estas condiciones, puedes dejar de usar la app en
          cualquier momento y eliminar tus documentos desde la biblioteca.
        </p>
      </div>
    </Sheet>
  );
}
