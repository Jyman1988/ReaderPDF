"use client";

import { useEffect, useState } from "react";
import { Loader2, Tv } from "lucide-react";
import { usePiAuth } from "@/contexts/pi-auth-context";
import { useReader } from "@/contexts/reader-context";
import { cx } from "./ui";

export function WatchAdButton({ className }: { className?: string }) {
  const { sdk } = usePiAuth();
  const { toast } = useReader();
  const [supported, setSupported] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!sdk) {
      setSupported(false);
      return;
    }
    sdk
      .isAdNetworkSupported()
      .then((ok) => {
        if (!cancelled) setSupported(ok);
      })
      .catch(() => {
        if (!cancelled) setSupported(false);
      });
    return () => {
      cancelled = true;
    };
  }, [sdk]);

  if (!sdk || !supported) return null;

  const onClick = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const watched = await sdk.showInterstitial();
      if (watched) {
        toast("¡Gracias por apoyar el proyecto viendo el anuncio!");
      }
    } catch {
      toast("No se pudo mostrar el anuncio. Intenta más tarde.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={busy}
      className={cx(
        "inline-flex items-center justify-center gap-1.5 self-center text-xs font-medium text-muted-foreground underline-offset-2 hover:underline disabled:opacity-50",
        className,
      )}
    >
      {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Tv className="h-3.5 w-3.5" aria-hidden="true" />}
      Ver un anuncio para apoyar el proyecto
    </button>
  );
}
