"use client";

import { normalizePage } from "./data";

const PDFJS_VERSION = "4.10.38";
const BASE = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${PDFJS_VERSION}/build/`;

interface TextItem {
  str?: string;
  hasEOL?: boolean;
}
interface PdfPage {
  getTextContent: () => Promise<{ items: TextItem[] }>;
  cleanup?: () => void;
}
interface PdfDoc {
  numPages: number;
  getPage: (n: number) => Promise<PdfPage>;
  getMetadata: () => Promise<{ info?: Record<string, unknown> }>;
  destroy: () => Promise<void>;
}
interface PdfLib {
  GlobalWorkerOptions: { workerSrc: string };
  getDocument: (src: Record<string, unknown>) => { promise: Promise<PdfDoc> };
}

let libPromise: Promise<PdfLib> | null = null;

function loadLib(): Promise<PdfLib> {
  if (!libPromise) {
    // Loaded at runtime from the CDN so the bundler never has to process pdf.js or its worker.
    const dynamicImport = new Function("u", "return import(u)") as (u: string) => Promise<PdfLib>;
    libPromise = dynamicImport(BASE + "pdf.min.mjs")
      .then((lib) => {
        lib.GlobalWorkerOptions.workerSrc = BASE + "pdf.worker.min.mjs";
        return lib;
      })
      .catch((e) => {
        libPromise = null;
        throw e;
      });
  }
  return libPromise;
}

export class PdfError extends Error {}

export interface ExtractedPdf {
  title: string;
  pages: string[];
}

export async function extractPdf(
  file: File,
  onProgress: (page: number, total: number) => void,
): Promise<ExtractedPdf> {
  let lib: PdfLib;
  try {
    lib = await loadLib();
  } catch {
    throw new PdfError("No se pudo cargar el lector de PDF. Revisa tu conexión e inténtalo de nuevo.");
  }

  const data = new Uint8Array(await file.arrayBuffer());
  let doc: PdfDoc;
  try {
    doc = await lib.getDocument({ data, isEvalSupported: false }).promise;
  } catch (e) {
    const name = (e as { name?: string })?.name;
    if (name === "PasswordException") throw new PdfError("Este PDF está protegido con contraseña.");
    throw new PdfError("No se pudo abrir el archivo. Asegúrate de que sea un PDF válido.");
  }

  try {
    const pages: string[] = [];
    for (let i = 1; i <= doc.numPages; i++) {
      onProgress(i, doc.numPages);
      const page = await doc.getPage(i);
      const content = await page.getTextContent();
      let raw = "";
      for (const it of content.items) {
        if (typeof it.str !== "string") continue;
        raw += it.str;
        if (it.hasEOL) raw += "\n";
      }
      pages.push(normalizePage(raw));
      page.cleanup?.();
    }

    let title = "";
    try {
      const meta = await doc.getMetadata();
      const t = meta.info?.Title;
      if (typeof t === "string") title = t.trim();
    } catch {
      /* no metadata */
    }

    if (!pages.some((p) => p.trim().length > 0)) {
      throw new PdfError("Este PDF no contiene texto legible (parece un documento escaneado).");
    }
    return { title, pages };
  } finally {
    void doc.destroy().catch(() => {});
  }
}
