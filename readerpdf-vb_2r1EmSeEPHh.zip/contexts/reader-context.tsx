"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { pi } from "@/lib/pi";
import {
  DEFAULT_PREFS,
  LIBRARY_KEY,
  MAX_DOCS,
  MAX_NOTES,
  NOTE_MAX,
  PREFS_KEY,
  buildDocText,
  docIdFor,
  makeId,
  notesKey,
  sanitizeLibrary,
  sanitizeNotes,
  sanitizePrefs,
  titleFromFile,
  type DocMeta,
  type DocText,
  type Note,
  type Prefs,
  type VoiceGender,
} from "@/lib/reader/data";
import { KeyWriter } from "@/lib/reader/store";
import { PdfError, extractPdf } from "@/lib/reader/pdf";
import { ttsSupported } from "@/lib/reader/tts";

export interface Toast {
  id: string;
  text: string;
}

export type AddResult = { ok: true; id: string } | { ok: false; error: string };

interface ReaderCtx {
  ready: boolean;
  loadError: boolean;
  retryLoad: () => void;
  storageTrouble: boolean;
  storageFull: boolean;
  dismissFull: () => void;
  prefs: Prefs;
  setVoice: (v: VoiceGender) => void;
  setRate: (r: number) => void;
  voices: SpeechSynthesisVoice[];
  library: DocMeta[];
  getDoc: (id: string) => DocMeta | undefined;
  getText: (id: string) => DocText | undefined;
  parsing: { page: number; total: number } | null;
  addPdf: (file: File) => Promise<AddResult>;
  removeDoc: (id: string) => void;
  savePos: (id: string, pos: number) => void;
  activeId: string | null;
  openDoc: (id: string) => void;
  closeDoc: () => void;
  notesFor: (id: string) => Note[] | null;
  addNote: (id: string, text: string, page: number) => void;
  updateNote: (id: string, noteId: string, text: string) => void;
  deleteNote: (id: string, noteId: string) => void;
  toasts: Toast[];
  toast: (text: string) => void;
}

const Ctx = createContext<ReaderCtx | null>(null);

export function useReader() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useReader must be used within ReaderProvider");
  return c;
}

export function ReaderProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [storageTrouble, setStorageTrouble] = useState(false);
  const [storageFull, setStorageFull] = useState(false);
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [library, setLibrary] = useState<DocMeta[]>([]);
  const [notes, setNotes] = useState<Map<string, Note[]>>(new Map());
  const [textVersion, setTextVersion] = useState(0);
  const [parsing, setParsing] = useState<{ page: number; total: number } | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  const prefsRef = useRef(prefs);
  const libraryRef = useRef<DocMeta[]>([]);
  const notesRef = useRef<Map<string, Note[]>>(new Map());
  const textsRef = useRef<Map<string, DocText>>(new Map());
  const loadingNotes = useRef<Set<string>>(new Set());

  const writerRef = useRef<KeyWriter | null>(null);
  if (!writerRef.current) {
    writerRef.current = new KeyWriter(({ trouble, full }) => {
      setStorageTrouble(trouble);
      if (full) setStorageFull(true);
    });
  }
  const writer = writerRef.current;

  const toast = useCallback((text: string) => {
    const id = makeId();
    setToasts((t) => [...t.slice(-2), { id, text }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoadError(false);
    Promise.all([pi.userState.get(PREFS_KEY), pi.userState.get(LIBRARY_KEY)])
      .then(([p, l]) => {
        if (cancelled) return;
        const np = sanitizePrefs(p);
        const nl = sanitizeLibrary(l);
        prefsRef.current = np;
        libraryRef.current = nl;
        setPrefs(np);
        setLibrary(nl);
        setReady(true);
      })
      .catch(() => {
        if (!cancelled) setLoadError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [loadAttempt]);

  useEffect(() => {
    if (!ttsSupported()) return;
    const synth = window.speechSynthesis;
    const update = () => setVoices(synth.getVoices());
    update();
    synth.addEventListener("voiceschanged", update);
    return () => synth.removeEventListener("voiceschanged", update);
  }, []);

  useEffect(() => {
    const flush = () => writer.flushNow();
    const onVis = () => {
      if (document.visibilityState === "hidden") flush();
    };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [writer]);

  const commitPrefs = useCallback(
    (next: Prefs) => {
      prefsRef.current = next;
      setPrefs(next);
      writer.schedule(PREFS_KEY, () => ({ ...prefsRef.current }), 600);
    },
    [writer],
  );

  const commitLibrary = useCallback(
    (next: DocMeta[], delay = 800) => {
      libraryRef.current = next;
      setLibrary(next);
      writer.schedule(LIBRARY_KEY, () => ({ items: libraryRef.current }), delay);
    },
    [writer],
  );

  const commitNotes = useCallback(
    (id: string, list: Note[]) => {
      const map = new Map(notesRef.current);
      map.set(id, list);
      notesRef.current = map;
      setNotes(map);
      writer.schedule(notesKey(id), () => ({ items: notesRef.current.get(id) ?? [] }), 700);
      commitLibrary(libraryRef.current.map((d) => (d.id === id ? { ...d, notes: list.length } : d)));
    },
    [writer, commitLibrary],
  );

  const loadNotes = useCallback((id: string) => {
    if (notesRef.current.has(id) || loadingNotes.current.has(id)) return;
    loadingNotes.current.add(id);
    pi.userState
      .get(notesKey(id))
      .then((rec) => {
        if (notesRef.current.has(id)) return;
        const map = new Map(notesRef.current);
        map.set(id, sanitizeNotes(rec));
        notesRef.current = map;
        setNotes(map);
      })
      .catch(() => {
        setTimeout(() => loadingNotes.current.delete(id), 3000);
      })
      .finally(() => {
        if (notesRef.current.has(id)) loadingNotes.current.delete(id);
      });
  }, []);

  const addPdf = useCallback(
    async (file: File): Promise<AddResult> => {
      const looksPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
      if (!looksPdf) return { ok: false, error: "Elige un archivo PDF." };
      const id = docIdFor(file.name, file.size);
      const existing = libraryRef.current.find((d) => d.id === id);
      if (!existing && libraryRef.current.length >= MAX_DOCS) {
        return { ok: false, error: `Tu biblioteca admite hasta ${MAX_DOCS} documentos. Elimina alguno para añadir más.` };
      }
      setParsing({ page: 0, total: 0 });
      try {
        const res = await extractPdf(file, (page, total) => setParsing({ page, total }));
        const docText = buildDocText(res.pages);
        textsRef.current.set(id, docText);
        setTextVersion((v) => v + 1);
        const now = Date.now();
        const chars = docText.text.length;
        const meta: DocMeta = existing
          ? { ...existing, pages: res.pages.length, chars, openedAt: now, pos: Math.min(existing.pos, chars) }
          : {
              id,
              title: (res.title && res.title.length > 2 ? res.title : titleFromFile(file.name)).slice(0, 120),
              fileName: file.name.slice(0, 200),
              size: file.size,
              pages: res.pages.length,
              chars,
              addedAt: now,
              openedAt: now,
              pos: 0,
              notes: 0,
            };
        commitLibrary([meta, ...libraryRef.current.filter((d) => d.id !== id)]);
        return { ok: true, id };
      } catch (e) {
        return { ok: false, error: e instanceof PdfError ? e.message : "No se pudo leer el PDF." };
      } finally {
        setParsing(null);
      }
    },
    [commitLibrary],
  );

  const removeDoc = useCallback(
    (id: string) => {
      commitLibrary(libraryRef.current.filter((d) => d.id !== id));
      textsRef.current.delete(id);
      const map = new Map(notesRef.current);
      map.delete(id);
      notesRef.current = map;
      setNotes(map);
      writer.cancel(notesKey(id));
      void pi.userState.delete(notesKey(id)).catch(() => {});
      if (activeId === id) setActiveId(null);
      toast("Documento eliminado");
    },
    [commitLibrary, writer, activeId, toast],
  );

  const savePos = useCallback(
    (id: string, pos: number) => {
      const cur = libraryRef.current.find((d) => d.id === id);
      if (!cur || cur.pos === pos) return;
      commitLibrary(
        libraryRef.current.map((d) => (d.id === id ? { ...d, pos: Math.max(0, Math.min(pos, d.chars)) } : d)),
        2500,
      );
    },
    [commitLibrary],
  );

  const openDoc = useCallback(
    (id: string) => {
      setActiveId(id);
      loadNotes(id);
      const now = Date.now();
      commitLibrary(
        libraryRef.current.map((d) => (d.id === id ? { ...d, openedAt: now } : d)).sort((a, b) => b.openedAt - a.openedAt),
        2000,
      );
    },
    [commitLibrary, loadNotes],
  );

  const addNote = useCallback(
    (id: string, text: string, page: number) => {
      const clean = text.trim().slice(0, NOTE_MAX);
      if (!clean) return;
      const list = notesRef.current.get(id) ?? [];
      if (list.length >= MAX_NOTES) {
        toast(`Máximo ${MAX_NOTES} notas por documento.`);
        return;
      }
      const now = Date.now();
      commitNotes(id, [{ id: makeId(), text: clean, page, createdAt: now, updatedAt: now }, ...list]);
    },
    [commitNotes, toast],
  );

  const updateNote = useCallback(
    (id: string, noteId: string, text: string) => {
      const clean = text.trim().slice(0, NOTE_MAX);
      if (!clean) return;
      const list = notesRef.current.get(id) ?? [];
      const now = Date.now();
      commitNotes(
        id,
        list.map((n) => (n.id === noteId ? { ...n, text: clean, updatedAt: now } : n)).sort((a, b) => b.updatedAt - a.updatedAt),
      );
    },
    [commitNotes],
  );

  const deleteNote = useCallback(
    (id: string, noteId: string) => {
      commitNotes(id, (notesRef.current.get(id) ?? []).filter((n) => n.id !== noteId));
    },
    [commitNotes],
  );

  const value = useMemo<ReaderCtx>(
    () => ({
      ready,
      loadError,
      retryLoad: () => setLoadAttempt((a) => a + 1),
      storageTrouble,
      storageFull,
      dismissFull: () => setStorageFull(false),
      prefs,
      setVoice: (voice) => commitPrefs({ ...prefsRef.current, voice }),
      setRate: (rate) => commitPrefs({ ...prefsRef.current, rate }),
      voices,
      library,
      getDoc: (id) => library.find((d) => d.id === id),
      getText: (id) => textsRef.current.get(id),
      parsing,
      addPdf,
      removeDoc,
      savePos,
      activeId,
      openDoc,
      closeDoc: () => setActiveId(null),
      notesFor: (id) => notes.get(id) ?? null,
      addNote,
      updateNote,
      deleteNote,
      toasts,
      toast,
    }),
    // textVersion forces consumers to re-read session texts after a new PDF is parsed
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [ready, loadError, storageTrouble, storageFull, prefs, voices, library, parsing, addPdf, removeDoc, savePos, activeId, openDoc, notes, addNote, updateNote, deleteNote, toasts, toast, commitPrefs, textVersion],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
