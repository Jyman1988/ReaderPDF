export type VoiceGender = "female" | "male";

export interface Prefs {
  voice: VoiceGender;
  rate: number;
}

export const RATES = [0.8, 1, 1.25, 1.5] as const;
export const DEFAULT_PREFS: Prefs = { voice: "female", rate: 1 };

export interface DocMeta {
  id: string;
  title: string;
  fileName: string;
  size: number;
  pages: number;
  chars: number;
  addedAt: number;
  openedAt: number;
  pos: number;
  notes: number;
}

export interface Note {
  id: string;
  text: string;
  page: number;
  createdAt: number;
  updatedAt: number;
}

export interface Segment {
  start: number;
  end: number;
  page: number;
}

export interface PageRange {
  page: number;
  start: number;
  end: number;
  firstSeg: number;
  lastSeg: number;
}

export interface DocText {
  text: string;
  pages: PageRange[];
  segments: Segment[];
}

export const PREFS_KEY = "readerpdf.prefs";
export const LIBRARY_KEY = "readerpdf.library";
export const notesKey = (id: string) => `readerpdf.n.${id}`;

export const MAX_DOCS = 40;
export const MAX_NOTES = 60;
export const NOTE_MAX = 1500;
const TITLE_MAX = 120;

export function makeId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export function docIdFor(fileName: string, size: number): string {
  let h = 0x811c9dc5;
  const s = `${fileName}|${size}`;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return "d" + h.toString(36);
}

export function titleFromFile(name: string): string {
  const base = name.replace(/\.pdf$/i, "").replace(/[_]+/g, " ").trim();
  return (base || "Documento sin título").slice(0, TITLE_MAX);
}

/* ---------- text building ---------- */

export function normalizePage(raw: string): string {
  const cleaned = raw
    .replace(/\r/g, "")
    .replace(/\u00ad/g, "")
    .replace(/(\p{L})-\n(\p{Ll})/gu, "$1$2");
  const lines = cleaned.split("\n").map((l) => l.replace(/[ \t\u00a0]+/g, " ").trim());
  let out = "";
  for (const line of lines) {
    if (!line) continue;
    if (!out) {
      out = line;
      continue;
    }
    const breakPara = /[.!?:…»"”]$/.test(out);
    out += (breakPara ? "\n" : " ") + line;
  }
  return out;
}

function isSpace(c: string | undefined) {
  return c === " " || c === "\n" || c === "\t";
}

export function buildDocText(pageTexts: string[]): DocText {
  let text = "";
  const pages: PageRange[] = [];
  const segments: Segment[] = [];

  pageTexts.forEach((pt, idx) => {
    if (text) text += "\n\n";
    const offset = text.length;
    text += pt;
    const firstSeg = segments.length;
    const n = pt.length;
    let s = 0;
    const push = (a: number, b: number) => {
      if (pt.slice(a, b).trim()) segments.push({ start: offset + a, end: offset + b, page: idx + 1 });
    };
    for (let i = 0; i < n; i++) {
      const c = pt[i];
      const endPunct = (c === "." || c === "!" || c === "?" || c === "…") && (i + 1 >= n || isSpace(pt[i + 1]));
      const tooLong = i - s >= 230 && c === " ";
      if (endPunct || c === "\n" || tooLong) {
        push(s, i + 1);
        s = i + 1;
      }
    }
    if (s < n) push(s, n);
    pages.push({ page: idx + 1, start: offset, end: offset + n, firstSeg, lastSeg: segments.length - 1 });
  });

  return { text, pages, segments };
}

export function segAt(segments: Segment[], pos: number): number {
  let lo = 0;
  let hi = segments.length - 1;
  let ans = 0;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (segments[mid].start <= pos) {
      ans = mid;
      lo = mid + 1;
    } else hi = mid - 1;
  }
  if (segments[ans] && pos >= segments[ans].end && ans + 1 < segments.length) return ans + 1;
  return ans;
}

/* ---------- formatting ---------- */

export function formatTime(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  const mm = h ? String(m).padStart(2, "0") : String(m);
  return (h ? `${h}:` : "") + `${mm}:${String(r).padStart(2, "0")}`;
}

export function relativeTime(ts: number, now = Date.now()): string {
  const d = Math.max(0, now - ts);
  const min = Math.floor(d / 60000);
  if (min < 1) return "ahora mismo";
  if (min < 60) return `hace ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `hace ${h} h`;
  const days = Math.floor(h / 24);
  if (days < 7) return `hace ${days} d`;
  return new Date(ts).toLocaleDateString("es-ES", { day: "numeric", month: "short" });
}

export function percentOf(meta: DocMeta): number {
  if (!meta.chars) return 0;
  return Math.min(100, Math.round((meta.pos / meta.chars) * 100));
}

/* ---------- sanitizers (stored data is untrusted) ---------- */

function obj(v: unknown): Record<string, unknown> | null {
  return v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : null;
}

export function unwrap(rec: unknown): Record<string, unknown> | null {
  const o = obj(rec);
  if (!o) return null;
  const blob = obj(o.blob);
  return blob ?? o;
}

function str(v: unknown, max: number): string {
  if (typeof v !== "string") return "";
  // eslint-disable-next-line no-control-regex
  return v.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").slice(0, max);
}

function num(v: unknown, fallback = 0): number {
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

const idOk = (v: unknown) => typeof v === "string" && /^[a-z0-9]{1,24}$/.test(v);

export function sanitizePrefs(rec: unknown): Prefs {
  const o = unwrap(rec);
  if (!o) return { ...DEFAULT_PREFS };
  const voice: VoiceGender = o.voice === "male" ? "male" : "female";
  const r = num(o.rate, 1);
  const rate = (RATES as readonly number[]).includes(r) ? r : 1;
  return { voice, rate };
}

export function sanitizeLibrary(rec: unknown): DocMeta[] {
  const o = unwrap(rec);
  const items = o && Array.isArray(o.items) ? o.items : [];
  const seen = new Set<string>();
  const out: DocMeta[] = [];
  for (const raw of items) {
    const it = obj(raw);
    if (!it || !idOk(it.id) || seen.has(it.id as string)) continue;
    seen.add(it.id as string);
    const chars = Math.max(0, Math.floor(num(it.chars)));
    out.push({
      id: it.id as string,
      title: str(it.title, TITLE_MAX) || "Documento sin título",
      fileName: str(it.fileName, 200),
      size: Math.max(0, Math.floor(num(it.size))),
      pages: Math.max(0, Math.floor(num(it.pages))),
      chars,
      addedAt: num(it.addedAt, Date.now()),
      openedAt: num(it.openedAt, Date.now()),
      pos: Math.min(chars, Math.max(0, Math.floor(num(it.pos)))),
      notes: Math.max(0, Math.floor(num(it.notes))),
    });
    if (out.length >= MAX_DOCS) break;
  }
  return out.sort((a, b) => b.openedAt - a.openedAt);
}

export function sanitizeNotes(rec: unknown): Note[] {
  const o = unwrap(rec);
  const items = o && Array.isArray(o.items) ? o.items : [];
  const seen = new Set<string>();
  const out: Note[] = [];
  for (const raw of items) {
    const it = obj(raw);
    if (!it || !idOk(it.id) || seen.has(it.id as string)) continue;
    const text = str(it.text, NOTE_MAX).trim();
    if (!text) continue;
    seen.add(it.id as string);
    out.push({
      id: it.id as string,
      text,
      page: Math.max(0, Math.floor(num(it.page))),
      createdAt: num(it.createdAt, Date.now()),
      updatedAt: num(it.updatedAt, Date.now()),
    });
    if (out.length >= MAX_NOTES) break;
  }
  return out.sort((a, b) => b.updatedAt - a.updatedAt);
}
