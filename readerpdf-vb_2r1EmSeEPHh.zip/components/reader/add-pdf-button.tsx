"use client";

import { useRef } from "react";
import type { ChangeEvent, ReactNode } from "react";
import { FilePlus2, Loader2 } from "lucide-react";
import { useReader } from "@/contexts/reader-context";
import { Button } from "./ui";

export function AddPdfButton({
  onAdded,
  label = "Agregar PDF",
  variant = "primary",
  icon,
}: {
  onAdded: (id: string) => void;
  label?: string;
  variant?: "primary" | "outline";
  icon?: ReactNode;
}) {
  const { addPdf, parsing, toast } = useReader();
  const inputRef = useRef<HTMLInputElement>(null);

  const onChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const res = await addPdf(file);
    if (res.ok) onAdded(res.id);
    else toast(res.error);
  };

  return (
    <>
      <input ref={inputRef} type="file" accept="application/pdf,.pdf" className="sr-only" tabIndex={-1} aria-hidden="true" onChange={onChange} />
      <Button block variant={variant} className="py-4 text-base" disabled={!!parsing} onClick={() => inputRef.current?.click()}>
        {parsing ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            {parsing.total ? `Leyendo página ${parsing.page} de ${parsing.total}…` : "Abriendo PDF…"}
          </>
        ) : (
          <>
            {icon ?? <FilePlus2 className="h-5 w-5" />}
            {label}
          </>
        )}
      </Button>
    </>
  );
}
