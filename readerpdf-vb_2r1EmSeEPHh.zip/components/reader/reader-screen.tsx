"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, AudioLines, FileUp, History, MousePointerClick, StickyNote, TextSelect, X } from "lucide-react";
import { percentOf, segAt } from "@/lib/reader/data";
import { TtsEngine, pickVoice, type TtsSnapshot } from "@/lib/reader/tts";
import { useReader } from "@/contexts/reader-context";
import { AddPdfButton } from "./add-pdf-button";
import { DocTextView } from "./doc-text-view";
import { NotesSheet } from "./notes-sheet";
import { PlayerBar } from "./player-bar";
import { VoiceSheet } from "./voice-sheet";
import { Button, IconButton, cx } from "./ui";

type Mode = "all" | "select" | "fragment";

export function ReaderScreen({ id }: { id: string }) {
  const { getDoc, getText, closeDoc, openDoc, prefs, voices, savePos, toast, notesFor } = useReader();
  const meta = getDoc(id);
  const doc = getText(id);

  const [snap, setSnap] = useState<TtsSnapshot | null>(null);
  const [mode, setMode] = useState<Mode>("all");
  const [selA, setSelA] = useState<number | null>(null);
  const [selB, setSelB] = useState<number | null>(null);
  const [frag, setFrag] = useState<{ lo: number; hi: number } | null>(null);
  const [started, setStarted] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);

  const engineRef = useRef<TtsEngine | null>(null);
  const modeRef = useRef<Mode>("all");
  modeRef.current = mode;
  const selRef = useRef<{ a: number | null; b: number | null }>({ a: null, b: null });
  selRef.current = { a: selA, b: selB };
  const startPosRef = useRef(meta?.pos ?? 0);

  useEffect(() => {
    if (!meta) closeDoc();
  }, [meta, closeDoc]);

  useEffect(() => {
    if (!doc) return;
    const eng = new TtsEngine(
      setSnap,
      () => toast(modeRef.current === "fragment" ? "Fragmento terminado" : "Has llegado al final del documento"),
      toast,
    );
    eng.load(doc.text, doc.segments, startPosRef.current);
    engineRef.current = eng;
    return () => {
      savePos(id, eng.snapshot.pos);
      eng.destroy();
      engineRef.current = null;
    };
  }, [doc, id, savePos, toast]);

  useEffect(() => {
    engineRef.current?.configure(pickVoice(voices, prefs.voice), prefs.rate);
  }, [doc, voices, prefs.voice, prefs.rate]);

  const seg = snap?.seg ?? -1;
  const playing = snap?.playing ?? false;

  useEffect(() => {
    if (!snap || !started) return;
    savePos(id, snap.pos);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seg, playing]);

  useEffect(() => {
    if (!playing || seg < 0) return;
    const el = document.querySelector<HTMLElement>(`[data-seg="${seg}"]`);
    if (!el) return;
    const r = el.getBoundingClientRect();
    if (r.top < 120 || r.bottom > window.innerHeight - 230) el.scrollIntoView({ block: "center", behavior: "smooth" });
  }, [seg, playing]);

  const onTap = useCallback(
    (i: number) => {
      const eng = engineRef.current;
      if (!eng || !doc) return;
      const m = modeRef.current;
      if (m === "select") {
        const a = selRef.current.a;
        const b = selRef.current.b;
        if (a === null) setSelA(i);
        else if (b === null) setSelB(i);
        else {
          setSelA(i);
          setSelB(null);
        }
        return;
      }
      const s = doc.segments[i];
      if (m === "fragment") {
        const { rangeStart, rangeEnd } = eng.snapshot;
        if (s.start < rangeStart || s.start >= rangeEnd) {
          toast("Pulsa «Leer todo» para salir del fragmento");
          return;
        }
      }
      setStarted(true);
      eng.jumpTo(s.start);
    },
    [doc, toast],
  );

  if (!meta) return null;

  const notesCount = notesFor(id)?.length ?? meta.notes;
  const currentPage = doc && seg >= 0 ? doc.segments[seg]?.page ?? 1 : 1;
  const voiceLabel = prefs.voice === "female" ? "Femenina" : "Masculina";

  const startSelect = () => {
    engineRef.current?.pause();
    if (frag) {
      engineRef.current?.clearRange();
      setFrag(null);
    }
    setSelA(null);
    setSelB(null);
    setMode("select");
  };

  const cancelSelect = () => {
    setSelA(null);
    setSelB(null);
    setMode(frag ? "fragment" : "all");
  };

  const readFragment = () => {
    const eng = engineRef.current;
    if (!eng || !doc || selA === null) return;
    const b = selB ?? selA;
    const lo = Math.min(selA, b);
    const hi = Math.max(selA, b);
    eng.setRange(doc.segments[lo].start, doc.segments[hi].end, doc.segments[lo].start);
    setFrag({ lo, hi });
    setMode("fragment");
    setSelA(null);
    setSelB(null);
    setStarted(true);
    eng.play();
  };

  const readAll = () => {
    engineRef.current?.clearRange();
    setFrag(null);
    setMode("all");
    setSelA(null);
    setSelB(null);
  };

  const selLo = mode === "select" && selA !== null ? Math.min(selA, selB ?? selA) : frag ? frag.lo : -1;
  const selHi = mode === "select" && selA !== null ? Math.max(selA, selB ?? selA) : frag ? frag.hi : -1;

  const rangeLabel =
    frag && doc
      ? `Fragmento · p. ${doc.segments[frag.lo].page}${doc.segments[frag.hi].page !== doc.segments[frag.lo].page ? `–${doc.segments[frag.hi].page}` : ""}`
      : "Todo el documento";

  const showContinue = !!doc && !started && startPosRef.current > 40 && startPosRef.current < doc.text.length - 20;
  const continuePage = doc ? doc.segments[segAt(doc.segments, startPosRef.current)]?.page ?? 1 : 1;

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col">
      <header className="sticky top-0 z-20 border-b border-border bg-background/90 px-2 py-2 backdrop-blur">
        <div className="flex items-center gap-1">
          <IconButton label="Volver a la biblioteca" onClick={closeDoc}>
            <ArrowLeft className="h-5 w-5" />
          </IconButton>
          <div className="min-w-0 flex-1 px-1">
            <h1 className="truncate text-[15px] font-semibold">{meta.title}</h1>
            <p className="text-xs text-muted-foreground">
              {doc ? `Página ${currentPage} de ${meta.pages}` : `${meta.pages} páginas · ${percentOf(meta)}% escuchado`}
            </p>
          </div>
          <IconButton label="Voz de lectura" onClick={() => setVoiceOpen(true)}>
            <AudioLines className="h-5 w-5" />
          </IconButton>
          <button
            type="button"
            onClick={() => setNotesOpen(true)}
            className="relative inline-flex h-10 items-center gap-1.5 rounded-full bg-secondary px-3 text-sm font-semibold text-secondary-foreground"
          >
            <StickyNote className="h-4 w-4" aria-hidden="true" />
            Notas
            {notesCount > 0 ? (
              <span className="rounded-full bg-primary px-1.5 text-[11px] leading-5 text-primary-foreground">{notesCount}</span>
            ) : null}
          </button>
        </div>

        {doc ? (
          <div className="mt-2 grid grid-cols-2 gap-1 rounded-xl bg-muted p-1" role="group" aria-label="Qué leer">
            <button
              type="button"
              onClick={readAll}
              aria-pressed={mode === "all"}
              className={cx("rounded-lg py-2 text-sm font-semibold transition", mode === "all" ? "bg-card shadow-sm" : "text-muted-foreground")}
            >
              Todo el documento
            </button>
            <button
              type="button"
              onClick={startSelect}
              aria-pressed={mode !== "all"}
              className={cx(
                "inline-flex items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-semibold transition",
                mode !== "all" ? "bg-card shadow-sm" : "text-muted-foreground",
              )}
            >
              <TextSelect className="h-4 w-4" aria-hidden="true" />
              {frag ? "Nuevo fragmento" : "Seleccionar fragmento"}
            </button>
          </div>
        ) : null}

        {mode === "select" ? (
          <div className="rp-rise mt-2 flex items-center gap-2 rounded-xl border border-primary/30 bg-secondary px-3 py-2">
            <MousePointerClick className="h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
            <p className="min-w-0 flex-1 text-xs leading-snug">
              {selA === null
                ? "Toca la frase donde empieza el fragmento."
                : selB === null
                  ? "Ahora toca la frase donde termina (o lee solo esta)."
                  : `Fragmento listo: ${Math.abs(selB - selA) + 1} frases.`}
            </p>
            <Button className="px-3 py-1.5 text-xs" disabled={selA === null} onClick={readFragment}>
              Leer fragmento
            </Button>
            <IconButton label="Cancelar selección" className="h-8 w-8" onClick={cancelSelect}>
              <X className="h-4 w-4" />
            </IconButton>
          </div>
        ) : null}
      </header>

      {!doc ? (
        <ReopenCard
          onAdded={(newId) => {
            if (newId !== id) {
              toast("Ese archivo es distinto: lo abrimos como un documento nuevo");
              openDoc(newId);
            }
          }}
          onNotes={() => setNotesOpen(true)}
        />
      ) : (
        <main className="flex-1 px-5 pb-72 pt-5">
          {showContinue ? (
            <div className="rp-rise mb-6 rounded-2xl border border-border bg-card p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <History className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">Continúa donde lo dejaste</p>
                  <p className="text-sm text-muted-foreground">
                    Página {continuePage} · {percentOf(meta)}% escuchado
                  </p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Button
                  onClick={() => {
                    setStarted(true);
                    engineRef.current?.jumpTo(startPosRef.current);
                    engineRef.current?.play();
                  }}
                >
                  Continuar
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setStarted(true);
                    engineRef.current?.jumpTo(0);
                    engineRef.current?.play();
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                >
                  Desde el inicio
                </Button>
              </div>
            </div>
          ) : null}

          <DocTextView
            doc={doc}
            active={seg}
            ws={snap?.wordStart ?? -1}
            we={snap?.wordEnd ?? -1}
            selLo={selLo}
            selHi={selHi}
            edgeA={mode === "select" ? selA ?? -1 : -1}
            edgeB={mode === "select" ? selB ?? -1 : -1}
            onTap={onTap}
          />
        </main>
      )}

      {doc && snap ? (
        <PlayerBar
          snap={snap}
          rate={prefs.rate}
          rangeLabel={rangeLabel}
          voiceLabel={voiceLabel}
          onToggle={() => {
            setStarted(true);
            engineRef.current?.toggle();
          }}
          onBack={() => {
            setStarted(true);
            engineRef.current?.seekBy(-10);
          }}
          onForward={() => {
            setStarted(true);
            engineRef.current?.seekBy(10);
          }}
          onScrub={(f) => {
            setStarted(true);
            engineRef.current?.jumpTo(snap.rangeStart + f * (snap.rangeEnd - snap.rangeStart));
          }}
          onVoice={() => setVoiceOpen(true)}
        />
      ) : null}

      <NotesSheet docId={id} open={notesOpen} onClose={() => setNotesOpen(false)} currentPage={doc ? currentPage : 0} />
      <VoiceSheet open={voiceOpen} onClose={() => setVoiceOpen(false)} onBeforePreview={() => engineRef.current?.pause()} />
    </div>
  );
}

function ReopenCard({ onAdded, onNotes }: { onAdded: (id: string) => void; onNotes: () => void }) {
  return (
    <main className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary">
        <FileUp className="h-7 w-7" aria-hidden="true" />
      </span>
      <h2 className="mt-4 text-lg font-semibold">Vuelve a elegir el archivo</h2>
      <p className="mt-2 max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
        Por privacidad, el PDF no se sube a ningún sitio: solo se lee en tu dispositivo. Selecciónalo de nuevo para
        escucharlo. Tu posición y tus notas siguen guardadas.
      </p>
      <div className="mt-6 flex w-full max-w-xs flex-col gap-2">
        <AddPdfButton onAdded={onAdded} label="Elegir el PDF" />
        <Button variant="outline" block onClick={onNotes}>
          <StickyNote className="h-4 w-4" />
          Ver mis notas
        </Button>
      </div>
    </main>
  );
}
