"use client";

import { AudioLines, Pause, Play, RotateCcw, RotateCw } from "lucide-react";
import { formatTime } from "@/lib/reader/data";
import { cpsFor, type TtsSnapshot } from "@/lib/reader/tts";

export function PlayerBar({
  snap,
  rate,
  rangeLabel,
  voiceLabel,
  onToggle,
  onBack,
  onForward,
  onScrub,
  onVoice,
}: {
  snap: TtsSnapshot;
  rate: number;
  rangeLabel: string;
  voiceLabel: string;
  onToggle: () => void;
  onBack: () => void;
  onForward: () => void;
  onScrub: (fraction: number) => void;
  onVoice: () => void;
}) {
  const len = Math.max(1, snap.rangeEnd - snap.rangeStart);
  const done = Math.max(0, Math.min(len, snap.pos - snap.rangeStart));
  const cps = cpsFor(rate);
  const value = Math.round((done / len) * 1000);

  return (
    <div className="fixed inset-x-0 bottom-0 z-30">
      <div className="mx-auto w-full max-w-2xl rounded-t-3xl border border-b-0 border-border bg-card px-5 pb-4 pt-3 shadow-[0_-8px_30px_-12px_rgba(20,30,60,0.25)] rp-safe-bottom">
        <div className="flex items-center justify-between gap-2 text-xs">
          <span className="truncate font-medium text-muted-foreground">{rangeLabel}</span>
          <button
            type="button"
            onClick={onVoice}
            className="inline-flex shrink-0 items-center gap-1 rounded-full bg-secondary px-2.5 py-1 font-semibold text-secondary-foreground"
          >
            <AudioLines className="h-3.5 w-3.5" aria-hidden="true" />
            {voiceLabel} · {String(rate).replace(".", ",")}×
          </button>
        </div>

        <label htmlFor="rp-progress" className="sr-only">
          Progreso de la lectura
        </label>
        <input
          id="rp-progress"
          type="range"
          min={0}
          max={1000}
          value={value}
          onChange={(e) => onScrub(Number(e.target.value) / 1000)}
          className="rp-range mt-3 w-full"
          style={{ ["--rp-fill" as string]: `${value / 10}%` }}
        />
        <div className="mt-1 flex justify-between text-[11px] tabular-nums text-muted-foreground">
          <span>{formatTime(done / cps)}</span>
          <span>{Math.round((done / len) * 100)}%</span>
          <span>aprox. {formatTime(len / cps)}</span>
        </div>

        <div className="mt-2 flex items-center justify-center gap-8">
          <button type="button" onClick={onBack} aria-label="Retroceder 10 segundos" className="relative flex h-12 w-12 items-center justify-center rounded-full hover:bg-muted active:scale-95">
            <RotateCcw className="h-7 w-7" aria-hidden="true" />
            <span className="absolute text-[9px] font-bold">10</span>
          </button>
          <button
            type="button"
            onClick={onToggle}
            aria-label={snap.playing ? "Pausa" : "Reproducir"}
            className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition active:scale-95"
          >
            {snap.playing ? <Pause className="h-7 w-7" fill="currentColor" /> : <Play className="ml-1 h-7 w-7" fill="currentColor" />}
          </button>
          <button type="button" onClick={onForward} aria-label="Avanzar 10 segundos" className="relative flex h-12 w-12 items-center justify-center rounded-full hover:bg-muted active:scale-95">
            <RotateCw className="h-7 w-7" aria-hidden="true" />
            <span className="absolute text-[9px] font-bold">10</span>
          </button>
        </div>
      </div>
    </div>
  );
}
