"use client";

import { segAt, type Segment, type VoiceGender } from "./data";

export interface TtsSnapshot {
  playing: boolean;
  pos: number;
  seg: number;
  wordStart: number;
  wordEnd: number;
  rangeStart: number;
  rangeEnd: number;
}

const BASE_CPS = 14;
export const cpsFor = (rate: number) => BASE_CPS * rate;

export function ttsSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined";
}

const FEMALE_RE =
  /female|mujer|m[oó]nica|paulina|helena|laura|luc[ií]a|elvira|sabina|conchita|pen[eé]lope|marisol|dalia|elena|sof[ií]a|isabel|carmen|paloma|ximena|francisca|angelica|google espa[nñ]ol/i;
const MALE_RE = /\bmale\b|hombre|jorge|diego|juan|carlos|pablo|[aá]lvaro|enrique|ra[uú]l|miguel|andr[eé]s|jos[eé]|gonzalo|jaime|tom[aá]s|alonso|manuel/i;

export interface VoiceChoice {
  voice: SpeechSynthesisVoice | null;
  pitch: number;
  exact: boolean;
}

export function pickVoice(all: SpeechSynthesisVoice[], gender: VoiceGender): VoiceChoice {
  const es = all.filter((v) => v.lang.toLowerCase().startsWith("es"));
  const pool = es.length ? es : all;
  const want = gender === "female" ? FEMALE_RE : MALE_RE;
  const avoid = gender === "female" ? MALE_RE : FEMALE_RE;
  const exact = pool.find((v) => want.test(v.name) && !(gender === "male" && /female/i.test(v.name)));
  if (exact) return { voice: exact, pitch: 1, exact: true };
  const fallback = pool.find((v) => !avoid.test(v.name)) ?? pool[0] ?? null;
  return { voice: fallback, pitch: gender === "male" ? 0.7 : 1.15, exact: false };
}

function wordLen(chunk: string, i: number): number {
  let j = i;
  while (j < chunk.length && !/\s/.test(chunk[j])) j++;
  return Math.max(1, j - i);
}

export class TtsEngine {
  private text = "";
  private segs: Segment[] = [];
  private token = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private current: SpeechSynthesisUtterance | null = null;
  private voice: SpeechSynthesisVoice | null = null;
  private pitch = 1;
  private rate = 1;
  private s: TtsSnapshot = { playing: false, pos: 0, seg: -1, wordStart: -1, wordEnd: -1, rangeStart: 0, rangeEnd: 0 };

  constructor(
    private onChange: (s: TtsSnapshot) => void,
    private onFinish: () => void,
    private onError: (msg: string) => void,
  ) {}

  get snapshot() {
    return this.s;
  }

  private emit() {
    this.s = { ...this.s };
    this.onChange(this.s);
  }

  load(text: string, segs: Segment[], pos: number) {
    this.stopSpeech();
    this.text = text;
    this.segs = segs;
    const p = Math.max(0, Math.min(pos, Math.max(0, text.length - 1)));
    this.s = { playing: false, pos: p, seg: segs.length ? segAt(segs, p) : -1, wordStart: -1, wordEnd: -1, rangeStart: 0, rangeEnd: text.length };
    this.emit();
  }

  configure(choice: VoiceChoice, rate: number) {
    const changed = choice.voice !== this.voice || choice.pitch !== this.pitch || rate !== this.rate;
    this.voice = choice.voice;
    this.pitch = choice.pitch;
    this.rate = rate;
    if (changed && this.s.playing) this.speakFrom(this.s.pos);
  }

  setRange(a: number, b: number, pos = a) {
    this.s.rangeStart = Math.max(0, a);
    this.s.rangeEnd = Math.min(this.text.length, b);
    const p = Math.max(this.s.rangeStart, Math.min(pos, this.s.rangeEnd - 1));
    if (this.s.playing) this.speakFrom(p);
    else {
      this.s.pos = p;
      this.s.seg = segAt(this.segs, p);
      this.emit();
    }
  }

  clearRange() {
    this.setRange(0, this.text.length, this.s.pos);
  }

  play() {
    if (!ttsSupported()) {
      this.onError("Tu navegador no permite la lectura en voz alta.");
      return;
    }
    if (!this.segs.length) return;
    let p = this.s.pos;
    if (p < this.s.rangeStart || p >= this.s.rangeEnd - 1) p = this.s.rangeStart;
    this.s.playing = true;
    this.speakFrom(p);
  }

  pause() {
    this.stopSpeech();
    this.s.playing = false;
    this.s.wordStart = -1;
    this.s.wordEnd = -1;
    this.emit();
  }

  toggle() {
    if (this.s.playing) this.pause();
    else this.play();
  }

  seekBy(sec: number) {
    this.jumpTo(this.s.pos + Math.round(sec * cpsFor(this.rate)));
  }

  jumpTo(pos: number) {
    const { rangeStart, rangeEnd } = this.s;
    let p = Math.max(rangeStart, Math.min(pos, Math.max(rangeStart, rangeEnd - 1)));
    while (p > rangeStart && !/\s/.test(this.text[p - 1] ?? " ")) p--;
    if (this.s.playing) this.speakFrom(p);
    else {
      this.s.pos = p;
      this.s.seg = segAt(this.segs, p);
      this.s.wordStart = -1;
      this.s.wordEnd = -1;
      this.emit();
    }
  }

  destroy() {
    this.stopSpeech();
  }

  private stopSpeech() {
    this.token++;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.current = null;
    if (ttsSupported()) window.speechSynthesis.cancel();
  }

  private finish() {
    this.stopSpeech();
    this.s.playing = false;
    this.s.pos = this.s.rangeEnd;
    this.s.wordStart = -1;
    this.s.wordEnd = -1;
    this.emit();
    this.onFinish();
  }

  private speakFrom(pos: number) {
    this.stopSpeech();
    const t = this.token;
    let p = pos;
    let idx = segAt(this.segs, p);
    while (idx < this.segs.length) {
      const seg = this.segs[idx];
      const start = Math.max(p, seg.start);
      const end = Math.min(seg.end, this.s.rangeEnd);
      if (start < end && this.text.slice(start, end).trim()) {
        this.speakChunk(t, idx, start, end);
        return;
      }
      if (seg.end >= this.s.rangeEnd) break;
      p = seg.end;
      idx++;
    }
    this.finish();
  }

  private speakChunk(t: number, idx: number, start: number, end: number) {
    const chunk = this.text.slice(start, end);
    const u = new SpeechSynthesisUtterance(chunk);
    if (this.voice) {
      u.voice = this.voice;
      u.lang = this.voice.lang;
    } else u.lang = "es-ES";
    u.rate = this.rate;
    u.pitch = this.pitch;

    u.onboundary = (e) => {
      if (t !== this.token) return;
      if (e.name && e.name !== "word") return;
      const abs = start + e.charIndex;
      const len = e.charLength > 0 ? e.charLength : wordLen(chunk, e.charIndex);
      this.s.pos = abs;
      this.s.wordStart = abs;
      this.s.wordEnd = abs + len;
      this.emit();
    };
    u.onend = () => {
      if (t !== this.token) return;
      this.s.pos = end;
      if (end >= this.s.rangeEnd) this.finish();
      else this.speakFrom(end);
    };
    u.onerror = (e) => {
      if (t !== this.token) return;
      if (e.error === "interrupted" || e.error === "canceled") return;
      this.s.playing = false;
      this.emit();
      this.onError("No se pudo reproducir la voz. Inténtalo de nuevo.");
    };

    this.current = u;
    this.s.pos = start;
    this.s.seg = idx;
    this.s.wordStart = -1;
    this.s.wordEnd = -1;
    this.emit();
    this.timer = setTimeout(() => {
      if (t !== this.token || !this.current) return;
      window.speechSynthesis.resume();
      window.speechSynthesis.speak(this.current);
    }, 40);
  }
}
