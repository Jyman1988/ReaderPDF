"use client";

import { Check, Volume2 } from "lucide-react";
import { RATES, type VoiceGender } from "@/lib/reader/data";
import { pickVoice, ttsSupported } from "@/lib/reader/tts";
import { useReader } from "@/contexts/reader-context";
import { Button, Sheet, cx } from "./ui";

const OPTIONS: { id: VoiceGender; label: string; sample: string }[] = [
  { id: "female", label: "Voz femenina", sample: "Hola, soy tu voz de lectura femenina." },
  { id: "male", label: "Voz masculina", sample: "Hola, soy tu voz de lectura masculina." },
];

export function VoiceSheet({ open, onClose, onBeforePreview }: { open: boolean; onClose: () => void; onBeforePreview?: () => void }) {
  const { prefs, setVoice, setRate, voices } = useReader();
  const supported = ttsSupported();

  const preview = (gender: VoiceGender) => {
    if (!supported) return;
    onBeforePreview?.();
    const choice = pickVoice(voices, gender);
    const synth = window.speechSynthesis;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(OPTIONS.find((o) => o.id === gender)?.sample ?? "Hola");
    if (choice.voice) {
      u.voice = choice.voice;
      u.lang = choice.voice.lang;
    } else u.lang = "es-ES";
    u.pitch = choice.pitch;
    u.rate = prefs.rate;
    synth.speak(u);
  };

  return (
    <Sheet open={open} onClose={onClose} title="Voz de lectura">
      {!supported ? (
        <p className="rounded-xl bg-muted p-3 text-sm text-muted-foreground">
          Tu navegador no permite la lectura en voz alta. Prueba con otro navegador.
        </p>
      ) : null}
      <div className="flex flex-col gap-3">
        {OPTIONS.map((o) => {
          const choice = pickVoice(voices, o.id);
          const active = prefs.voice === o.id;
          return (
            <div
              key={o.id}
              className={cx(
                "flex items-center gap-3 rounded-2xl border-2 p-3 transition",
                active ? "border-primary bg-secondary" : "border-border bg-card",
              )}
            >
              <button type="button" className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => setVoice(o.id)} aria-pressed={active}>
                <span className={cx("flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2", active ? "border-primary bg-primary text-primary-foreground" : "border-border")}>
                  {active ? <Check className="h-3.5 w-3.5" /> : null}
                </span>
                <span className="min-w-0">
                  <span className="block font-semibold">{o.label}</span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {choice.voice ? choice.voice.name : "Voz del sistema"}
                    {choice.exact ? "" : " · tono ajustado"}
                  </span>
                </span>
              </button>
              <Button variant="outline" className="px-3 py-2" onClick={() => preview(o.id)} disabled={!supported}>
                <Volume2 className="h-4 w-4" />
                Probar
              </Button>
            </div>
          );
        })}
      </div>

      <h3 className="mt-6 text-sm font-semibold">Velocidad</h3>
      <div className="mt-2 grid grid-cols-4 gap-2">
        {RATES.map((r) => (
          <button
            key={r}
            type="button"
            onClick={() => setRate(r)}
            aria-pressed={prefs.rate === r}
            className={cx(
              "rounded-xl border py-2.5 text-sm font-semibold tabular-nums transition",
              prefs.rate === r ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card",
            )}
          >
            {String(r).replace(".", ",")}×
          </button>
        ))}
      </div>
      <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
        Las voces disponibles dependen de tu dispositivo. Si no hay una voz del tipo elegido, ajustamos el tono de la
        voz en español. Tu elección se guarda para todos tus documentos.
      </p>
    </Sheet>
  );
}
