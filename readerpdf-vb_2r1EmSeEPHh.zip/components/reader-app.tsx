"use client";

import { BookOpen, Loader2 } from "lucide-react";
import { ReaderProvider, useReader } from "@/contexts/reader-context";
import { LibraryScreen } from "./reader/library-screen";
import { ReaderScreen } from "./reader/reader-screen";
import { StorageFullSheet } from "./reader/storage-full-sheet";
import { Button, StorageNotice, ToastHost } from "./reader/ui";

function Shell() {
  const { ready, loadError, retryLoad, activeId } = useReader();

  if (!ready) {
    return (
      <main className="flex min-h-dvh flex-col items-center justify-center gap-4 px-6 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
          <BookOpen className="h-7 w-7" aria-hidden="true" />
        </span>
        {loadError ? (
          <>
            <p className="max-w-xs text-sm text-muted-foreground">No pudimos cargar tu biblioteca. Comprueba tu conexión.</p>
            <Button onClick={retryLoad}>Reintentar</Button>
          </>
        ) : (
          <p className="inline-flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            Cargando tu biblioteca…
          </p>
        )}
      </main>
    );
  }

  return (
    <>
      {activeId ? <ReaderScreen key={activeId} id={activeId} /> : <LibraryScreen />}
      <ToastHost />
      <StorageNotice />
      <StorageFullSheet />
    </>
  );
}

export function ReaderApp() {
  return (
    <ReaderProvider>
      <Shell />
    </ReaderProvider>
  );
}
