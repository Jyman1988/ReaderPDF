"use client";

import { useState } from "react";
import { AudioLines, BookOpen, FileText, ShieldCheck, StickyNote, Trash2 } from "lucide-react";
import { percentOf, relativeTime, type DocMeta } from "@/lib/reader/data";
import { useReader } from "@/contexts/reader-context";
import { AddPdfButton } from "./add-pdf-button";
import { DonateButton } from "./donate-button";
import { LegalSheet } from "./legal-sheet";
import { VoiceSheet } from "./voice-sheet";
import { WatchAdButton } from "./watch-ad-button";
import { IconButton, cx } from "./ui";

export function LibraryScreen() {
  const { library, openDoc, prefs } = useReader();
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [legalOpen, setLegalOpen] = useState(false);

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-4 pb-10 pt-5">
      <header className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
            <BookOpen className="h-5 w-5" aria-hidden="true" />
          </span>
          <div>
            <h1 className="text-xl font-bold tracking-tight">ReaderPDF</h1>
            <p className="text-xs text-muted-foreground">Escucha tus libros y apuntes</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setVoiceOpen(true)}
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-2 text-xs font-semibold"
        >
          <AudioLines className="h-4 w-4 text-primary" aria-hidden="true" />
          {prefs.voice === "female" ? "Voz femenina" : "Voz masculina"}
        </button>
      </header>

      <section className="mt-6 rounded-3xl bg-primary p-5 text-primary-foreground">
        <h2 className="text-balance text-2xl font-bold leading-tight">
          Estudia escuchando. <span className="rp-hero-mark">Tú eliges qué leer.</span>
        </h2>
        <p className="mt-2 text-pretty text-sm leading-relaxed opacity-85">
          Añade un PDF con texto, escúchalo entero o solo el fragmento que necesites repasar.
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <AddPdfButton onAdded={openDoc} variant="outline" />
          <DonateButton className="border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20" />
        </div>
      </section>

      <section className="mt-8" aria-labelledby="lib-title">
        <div className="mb-3 flex items-baseline justify-between">
          <h2 id="lib-title" className="text-base font-semibold">
            Mi biblioteca
          </h2>
          {library.length ? <span className="text-xs text-muted-foreground">{library.length} documentos</span> : null}
        </div>

        {library.length === 0 ? (
          <div className="flex flex-col items-center rounded-3xl border-2 border-dashed border-border px-6 py-12 text-center">
            <FileText className="h-10 w-10 text-muted-foreground" aria-hidden="true" />
            <p className="mt-3 font-semibold">Todavía no hay documentos</p>
            <p className="mt-1 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Agrega tu primer libro, temario o apuntes en PDF para empezar a escucharlo.
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-3">
            {library.map((d) => (
              <DocRow key={d.id} doc={d} onOpen={() => openDoc(d.id)} />
            ))}
          </ul>
        )}
      </section>

      <div className="mt-8 flex flex-col items-center gap-3">
        <WatchAdButton />
        <button
          type="button"
          onClick={() => setLegalOpen(true)}
          className="inline-flex items-center justify-center gap-1.5 text-xs font-medium text-muted-foreground underline-offset-2 hover:underline"
        >
          <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
          Privacidad y condiciones de uso
        </button>
      </div>

      <VoiceSheet open={voiceOpen} onClose={() => setVoiceOpen(false)} />
      <LegalSheet open={legalOpen} onClose={() => setLegalOpen(false)} />
    </div>
  );
}

function DocRow({ doc, onOpen }: { doc: DocMeta; onOpen: () => void }) {
  const { removeDoc } = useReader();
  const [confirm, setConfirm] = useState(false);
  const pct = percentOf(doc);

  return (
    <li className="rp-rise flex items-stretch gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm">
      <button type="button" onClick={onOpen} className="flex min-w-0 flex-1 items-center gap-3 rounded-xl p-2 text-left">
        <span className="flex h-12 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
          <FileText className="h-5 w-5" aria-hidden="true" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate font-semibold">{doc.title}</span>
          <span className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-muted-foreground">
            <span>{doc.pages} págs.</span>
            <span>{pct > 0 ? `${pct}% escuchado` : "Sin empezar"}</span>
            {doc.notes > 0 ? (
              <span className="inline-flex items-center gap-0.5">
                <StickyNote className="h-3 w-3" aria-hidden="true" />
                {doc.notes}
              </span>
            ) : null}
            <span>{relativeTime(doc.openedAt)}</span>
          </span>
          <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden="true">
            <span className="block h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
          </span>
        </span>
      </button>
      {confirm ? (
        <div className="flex flex-col justify-center gap-1">
          <button type="button" className="rounded-lg bg-destructive px-2.5 py-1.5 text-xs font-semibold text-primary-foreground" onClick={() => removeDoc(doc.id)}>
            Eliminar
          </button>
          <button type="button" className="rounded-lg px-2.5 py-1.5 text-xs font-medium hover:bg-muted" onClick={() => setConfirm(false)}>
            Cancelar
          </button>
        </div>
      ) : (
        <IconButton label="Eliminar documento" className={cx("self-center text-muted-foreground")} onClick={() => setConfirm(true)}>
          <Trash2 className="h-4 w-4" />
        </IconButton>
      )}
    </li>
  );
}
