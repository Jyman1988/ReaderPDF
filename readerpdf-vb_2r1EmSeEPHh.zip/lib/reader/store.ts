"use client";

import { pi } from "@/lib/pi";

type Builder = () => Record<string, unknown>;
export interface WriterStatus {
  trouble: boolean;
  full: boolean;
}

const MIN_PER_KEY = 5200;
const MIN_ACROSS = 2100;
const BACKOFF_START = 3000;
const BACKOFF_MAX = 30000;

function isFullError(err: unknown): boolean {
  const e = err as { status?: number; data?: unknown; message?: string } | null;
  if (!e) return false;
  if (e.status === 429) return false;
  if (e.status === 413 || e.status === 507) return true;
  const text = `${e.message ?? ""} ${typeof e.data === "string" ? e.data : JSON.stringify(e.data ?? "")}`.toLowerCase();
  return /quota|storage full|too many keys|limit exceeded|total size/.test(text);
}

export class KeyWriter {
  private lastAny = 0;
  private pending = new Map<string, Builder>();
  private timers = new Map<string, ReturnType<typeof setTimeout>>();
  private lastWrite = new Map<string, number>();
  private backoff = new Map<string, number>();
  private inFlight = new Set<string>();
  private failing = new Set<string>();

  constructor(private onStatus: (s: WriterStatus) => void) {}

  schedule(key: string, build: Builder, delay = 800) {
    this.pending.set(key, build);
    this.arm(key, delay);
  }

  cancel(key: string) {
    this.pending.delete(key);
    const t = this.timers.get(key);
    if (t) clearTimeout(t);
    this.timers.delete(key);
    this.failing.delete(key);
    this.report(false);
  }

  private arm(key: string, delay: number) {
    const t = this.timers.get(key);
    if (t) clearTimeout(t);
    this.timers.set(
      key,
      setTimeout(() => this.run(key), Math.max(0, delay)),
    );
  }

  private report(full: boolean) {
    this.onStatus({ trouble: this.failing.size > 0, full });
  }

  private run(key: string) {
    this.timers.delete(key);
    const build = this.pending.get(key);
    if (!build) return;
    if (this.inFlight.has(key)) return this.arm(key, 600);
    const now = Date.now();
    const readyAt = Math.max((this.lastWrite.get(key) ?? 0) + MIN_PER_KEY, this.lastAny + MIN_ACROSS);
    if (readyAt > now) return this.arm(key, readyAt - now);

    this.pending.delete(key);
    this.inFlight.add(key);
    this.lastAny = now;
    this.lastWrite.set(key, now);
    let blob: Record<string, unknown>;
    try {
      blob = build();
    } catch {
      this.inFlight.delete(key);
      return;
    }
    pi.userState
      .set(key, blob)
      .then(() => {
        this.backoff.delete(key);
        this.failing.delete(key);
        this.report(false);
      })
      .catch((err) => {
        if (!this.pending.has(key)) this.pending.set(key, build);
        const b = Math.min(BACKOFF_MAX, (this.backoff.get(key) ?? BACKOFF_START / 1.8) * 1.8);
        this.backoff.set(key, b);
        this.failing.add(key);
        this.report(isFullError(err));
        this.arm(key, b);
      })
      .finally(() => {
        this.inFlight.delete(key);
      });
  }

  flushNow() {
    for (const [key, build] of this.pending) {
      try {
        void pi.userState.set(key, build()).catch(() => {});
      } catch {
        /* ignore */
      }
    }
  }
}
