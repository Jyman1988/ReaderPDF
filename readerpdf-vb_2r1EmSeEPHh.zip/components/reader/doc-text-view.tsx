"use client";

import { memo } from "react";
import type { ReactNode } from "react";
import type { DocText, PageRange, Segment } from "@/lib/reader/data";

type SegState = "none" | "sel" | "edge" | "active";

const Seg = memo(function Seg({
  i,
  text,
  state,
  ws,
  we,
  onTap,
}: {
  i: number;
  text: string;
  state: SegState;
  ws: number;
  we: number;
  onTap: (i: number) => void;
}) {
  let content: ReactNode = text;
  if (state === "active" && ws >= 0 && we > ws) {
    content = (
      <>
        {text.slice(0, ws)}
        <mark className="rp-word">{text.slice(ws, we)}</mark>
        {text.slice(we)}
      </>
    );
  }
  return (
    <span
      data-seg={i}
      onClick={() => onTap(i)}
      className={
        state === "active" ? "rp-seg rp-active" : state === "edge" ? "rp-seg rp-sel rp-edge" : state === "sel" ? "rp-seg rp-sel" : "rp-seg"
      }
    >
      {content}
    </span>
  );
});

const Page = memo(function Page({
  range,
  text,
  segments,
  active,
  ws,
  we,
  lo,
  hi,
  edgeA,
  edgeB,
  onTap,
}: {
  range: PageRange;
  text: string;
  segments: Segment[];
  active: number;
  ws: number;
  we: number;
  lo: number;
  hi: number;
  edgeA: number;
  edgeB: number;
  onTap: (i: number) => void;
}) {
  const parts: ReactNode[] = [];
  let cursor = range.start;
  for (let i = range.firstSeg; i <= range.lastSeg; i++) {
    const seg = segments[i];
    if (seg.start > cursor) parts.push(text.slice(cursor, seg.start));
    const state: SegState =
      i === active ? "active" : i === edgeA || i === edgeB ? "edge" : lo >= 0 && i >= lo && i <= hi ? "sel" : "none";
    parts.push(
      <Seg
        key={i}
        i={i}
        text={text.slice(seg.start, seg.end)}
        state={state}
        ws={i === active ? ws - seg.start : -1}
        we={i === active ? we - seg.start : -1}
        onTap={onTap}
      />,
    );
    cursor = seg.end;
  }
  if (cursor < range.end) parts.push(text.slice(cursor, range.end));

  return (
    <section className="rp-page" aria-label={`Página ${range.page}`}>
      <div className="mb-3 flex items-center gap-3 text-xs font-medium text-muted-foreground">
        <span>Página {range.page}</span>
        <span className="h-px flex-1 bg-border" aria-hidden="true" />
      </div>
      {parts.length ? (
        <p className="whitespace-pre-wrap break-words font-serif text-[17px] leading-[1.75] text-foreground">{parts}</p>
      ) : (
        <p className="text-sm italic text-muted-foreground">Esta página no tiene texto.</p>
      )}
    </section>
  );
});

export function DocTextView({
  doc,
  active,
  ws,
  we,
  selLo,
  selHi,
  edgeA,
  edgeB,
  onTap,
}: {
  doc: DocText;
  active: number;
  ws: number;
  we: number;
  selLo: number;
  selHi: number;
  edgeA: number;
  edgeB: number;
  onTap: (i: number) => void;
}) {
  return (
    <div className="flex flex-col gap-8">
      {doc.pages.map((p) => {
        const has = (i: number) => i >= p.firstSeg && i <= p.lastSeg;
        const hit = active >= 0 && has(active);
        const selHit = selLo >= 0 && selHi >= p.firstSeg && selLo <= p.lastSeg;
        return (
          <Page
            key={p.page}
            range={p}
            text={doc.text}
            segments={doc.segments}
            active={hit ? active : -1}
            ws={hit ? ws : -1}
            we={hit ? we : -1}
            lo={selHit ? selLo : -1}
            hi={selHit ? selHi : -1}
            edgeA={has(edgeA) ? edgeA : -1}
            edgeB={has(edgeB) ? edgeB : -1}
            onTap={onTap}
          />
        );
      })}
    </div>
  );
}
